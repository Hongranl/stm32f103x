var searchData=
[
  ['manager_5fconfig',['MANAGER_CONFIG',['../struct_m_a_n_a_g_e_r___c_o_n_f_i_g.html',1,'']]]
];
