var searchData=
[
  ['felica_5fanticollision',['FELICA_Anticollision',['../group__lib__iso18092pcd___public___functions.html#ga7663afd8b11df446cc9da665e854d4f5',1,'FELICA_Anticollision(void):&#160;lib_iso18092pcd.c'],['../group__lib__iso18092pcd___public___functions.html#ga7663afd8b11df446cc9da665e854d4f5',1,'FELICA_Anticollision(void):&#160;lib_iso18092pcd.c']]],
  ['felica_5fcardtest',['FELICA_CardTest',['../group__lib__iso18092pcd___public___functions.html#gaecf8ce9333a044b37111ceda7bf00b57',1,'FELICA_CardTest(void):&#160;lib_iso18092pcd.c'],['../group__lib__iso18092pcd___public___functions.html#gaecf8ce9333a044b37111ceda7bf00b57',1,'FELICA_CardTest(void):&#160;lib_iso18092pcd.c']]],
  ['felica_5fispresent',['FELICA_IsPresent',['../group__lib__iso18092pcd___public___functions.html#ga1cef20e925d1f55606356b0ad023a16f',1,'FELICA_IsPresent(void):&#160;lib_iso18092pcd.c'],['../group__lib__iso18092pcd___public___functions.html#ga1cef20e925d1f55606356b0ad023a16f',1,'FELICA_IsPresent(void):&#160;lib_iso18092pcd.c']]]
];
