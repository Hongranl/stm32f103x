var searchData=
[
  ['felica_5fcard',['FELICA_CARD',['../struct_f_e_l_i_c_a___c_a_r_d.html',1,'']]]
];
