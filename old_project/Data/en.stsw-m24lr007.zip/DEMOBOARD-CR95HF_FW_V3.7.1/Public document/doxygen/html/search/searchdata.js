var indexSectionsWithContent =
{
  0: "9_abcdefhilmprstu",
  1: "abdfhim",
  2: "dlm",
  3: "acdfipst",
  4: "u",
  5: "r",
  6: "eiprt",
  7: "_cdilp",
  8: "9"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "defines",
  7: "groups",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Macros",
  7: "Modules",
  8: "Pages"
};

