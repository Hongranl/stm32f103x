var searchData=
[
  ['iso14443a_5fcard',['ISO14443A_CARD',['../struct_i_s_o14443_a___c_a_r_d.html',1,'']]],
  ['iso14443b_5fcard',['ISO14443B_CARD',['../struct_i_s_o14443_b___c_a_r_d.html',1,'']]],
  ['iso15693configstruct',['ISO15693ConfigStruct',['../struct_i_s_o15693_config_struct.html',1,'']]]
];
